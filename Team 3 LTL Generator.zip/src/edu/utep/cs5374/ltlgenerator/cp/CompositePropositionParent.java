package edu.utep.cs5374.ltlgenerator.cp;

public interface CompositePropositionParent {

	public String compute(int numProposition, char charValue);
}
