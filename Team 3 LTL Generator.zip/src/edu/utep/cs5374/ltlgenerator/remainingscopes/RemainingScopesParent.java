package edu.utep.cs5374.ltlgenerator.remainingscopes;

public abstract class RemainingScopesParent {
	
	public abstract String getFormula(String P_ltl, String Q_ltl, String R_ltl, String L_ltl, int numProposition);
}
