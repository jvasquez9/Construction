package edu.utep.cs5374.ltlgenerator.globalscope;

public abstract class GlobalScopeParent {

	public abstract String getFormula(String P_ltl, String Q_ltl, int numProposition);
	
}